# MyFirstApp
MyFirstApp with firebase

## Splash_Screen
![](screenshot/splash.PNG)

## Main_Screen
![](screenshot/main.PNG)


## Donator_Register_Screen
![](screenshot/d_register.PNG)


## Rider_Register_Screen
![](screenshot/r_register.PNG)


## Login_Screen
![](screenshot/login.PNG)


## Donator_Home
![](screenshot/d_home.PNG)


## Rider_Home
![](screenshot/r_home.PNG)


## Donator_add_donation
![](screenshot/d_adddonation.PNG)


## Donator_status
![](screenshot/d_status.PNG)


## Donator_History
![](screenshot/d_history.PNG)


## Donator_Navigation_View
![](screenshot/d_navigation.PNG)



## Donator_Profile
![](screenshot/d_profile.PNG)


## Rider_Donations
![](screenshot/r_donations.PNG)


## Rider_complete_Donations
![](screenshot/r_complete.PNG)



## Rider_Images_Upload
![](screenshot/r_uploadimages.PNG)


## Rider_History
![](screenshot/r_history.PNG)


## Rider_Profile
![](screenshot/r_profile.PNG)

